const gridOptions = {
  // define grid columns
  columnDefs: [
    { field: 'name' },
    // Using dot notation to access nested property
    { field: 'medals.gold', headerName: 'Gold' },
    // Show default header name
    { field: 'person.age' },
  ],
  rowData: getData(),
  onCellMouseOver :function(params) {
      console.log("onCellMouseOver.............",params.event.target)
          // debugger;

   let element= document.getElementById("floatbox");
   if(element){
    element.remove();
   }
   
  let flaotLable1="<div id='floatbox'>mdhu</div>"
    let flaotLable =  '<div id="floatbox"><div class="btn-group"> <button type="button" class="btn btn-primary"><i  id="addAction" class="fa fa-plus"></i></button><button type="button" class="btn btn-primary"><i  id="editAction" class="fa fa-pencil"></i></button><button type="button" class="btn btn-primary"><i class="fa fa-close" id="removeAction"></i></button></div>'
    params.event.target.insertAdjacentHTML('afterbegin',flaotLable);
    if(document.getElementById('floatbox')){
document.getElementById('floatbox').addEventListener('click', function (e) {
       alert(e.target.id);
      });
    }
    

  },
  onCellMouseOut  :function(params) {
    if(false){
    console.log("mouseout.............")
   let element= document.getElementById("floatbox");
   if(element){
    element.remove();
   }
    }
   
  }
};




// setup the grid after the page has finished loading
document.addEventListener('DOMContentLoaded', function () {
  var gridDiv = document.querySelector('#myGrid');
  new agGrid.Grid(gridDiv, gridOptions);
});
