window.menujson =[
  {
    "name": "Administration",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Organization",
        "type": "process",
        "event": {
          "process": "process_Organization_2233568"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Sub Organization",
        "type": "process",
        "event": {
          "process": "process_SubOrganization_2233590"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Calendar",
        "type": "process",
        "event": {
          "process": "process_calendar_103433"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Certificate Reminder",
        "type": "process",
        "event": {
          "process": "process_CertificateSchedulers_2487219"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Financial Year Setup",
        "type": "process",
        "event": {
          "process": "process_FinancialYearSetup_2510789"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Sequence Repository",
        "type": "process",
        "event": {
          "process": "process_SequenceHolder_6498383"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Department",
        "type": "process",
        "event": {
          "process": "process_Department_7"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Section",
        "type": "process",
        "event": {
          "process": "process_Deptsection_325208"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Position",
        "type": "process",
        "event": {
          "process": "process_Designation_6"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "App Config",
        "type": "process",
        "event": {
          "process": "process_ThresholdHours_2510692"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Process Transformation",
        "type": "process",
        "event": {
          "process": "process_ProcessTransformations_2529594"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Activity Log",
        "type": "process",
        "event": {
          "process": "process_ActivityLog_2558400"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Role and Sign",
        "type": "process",
        "event": {
          "process": "process_RoleAndSign_2558399"
        },
        "favourite": false,
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Hrms",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Configuration",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Setup",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Employee No Prefix",
                "type": "process",
                "event": {
                  "process": "process_EmpNoPrefix_2538746"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Designation Role Mapping",
                "type": "process",
                "event": {
                  "process": "process_DesignationRoleMapping_2519014"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Leave Transformation",
                "type": "process",
                "event": {
                  "process": "process_LeaveTransformations_2521636"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Onduty Transformation",
                "type": "process",
                "event": {
                  "process": "process_OndutyTransformations_2520284"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Advance Transformation",
                "type": "process",
                "event": {
                  "process": "process_AdvanceTransformation_2505918"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Shifts And Breaks",
                "type": "process",
                "event": {
                  "process": "process_Shifts_2507452"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Salary Component",
                "type": "process",
                "event": {
                  "process": "process_ComponentHeads_2509683"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Bio-metric Setup",
                "type": "process",
                "event": {
                  "process": "process_EmployeeIdOnTime_2523317"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Grade",
                "type": "process",
                "event": {
                  "process": "process_Grade_2455"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Employment Type",
                "type": "process",
                "event": {
                  "process": "process_EmploymentType_12"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Leave Type",
                "type": "process",
                "event": {
                  "process": "process_LeaveType_17"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Threshold Setup",
                "type": "process",
                "event": {
                  "process": "process_ThresholdHours_2510692"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Policy",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Employee Policy",
                "type": "process",
                "event": {
                  "process": "process_EmployeePolicy_2501056"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Leave Policy",
                "type": "process",
                "event": {
                  "process": "process_LeavePolicy_2503660"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Overtime Policy",
                "type": "process",
                "event": {
                  "process": "process_overtimepolicySetup_2524774"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "OnDuty Policy",
                "type": "process",
                "event": {
                  "process": "process_OnDutyPolicy_2505588"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Loan Policy",
                "type": "process",
                "event": {
                  "process": "process_LoanPolicy_2512576"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Advance Policy",
                "type": "process",
                "event": {
                  "process": "process_AdvancePolicy_2511810"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Claim Policy",
                "type": "process",
                "event": {
                  "process": "process_ClaimPolicy_2511591"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Recruitment",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Manpower Requisition",
            "type": "process",
            "event": {
              "process": "process_ManpowerRequisition_2499413"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Candidate Hiring",
            "type": "process",
            "event": {
              "process": "process_Candidate_2499513"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Employee Management",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Employee",
            "type": "process",
            "event": {
              "process": "process_Employee_2500921"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Transfer",
            "type": "process",
            "event": {
              "process": "process_EmployeeTransfer_2501523"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Exit",
            "type": "process",
            "event": {
              "process": "process_EmployeeTermination_2502060"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Redundancy",
            "type": "process",
            "event": {
              "process": "process_EmployeeTermination_2502238"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Query Repository",
            "type": "process",
            "event": {
              "process": "process_EmployeeQueryRepository_2506752"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Shift Modification",
            "type": "process",
            "event": {
              "process": "process_ShiftsChange_2536284"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Self Services",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Hierarchy",
            "type": "process",
            "event": {
              "process": "process_EmployeesDirectory_2512466"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "My Profile",
            "type": "process",
            "event": {
              "process": "process_EmployeeDetails_2512492"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Associate Directory",
            "type": "process",
            "event": {
              "process": "process_AssociateDirectory_2520310"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Leave Ledger",
            "type": "process",
            "event": {
              "process": "process_LeaveLedger_2512737"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Requests",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Leave Request",
            "type": "process",
            "event": {
              "process": "process_LeaveForfixedAndPermanent_2499378"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Onduty Request",
            "type": "process",
            "event": {
              "process": "process_OnDutyCreation_2505475"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Loan Request",
            "type": "process",
            "event": {
              "process": "process_Loans_2512036"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Advance Request",
            "type": "process",
            "event": {
              "process": "process_AdvanceRequest_2505898"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Claim Request",
            "type": "process",
            "event": {
              "process": "process_ClaimRequest_2511639"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Approvals",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Employee Transfer Approval",
            "type": "process",
            "event": {
              "process": "process_EmployeeTransferApproval_2518862"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Exit Approval",
            "type": "process",
            "event": {
              "process": "process_EmployeeResignationApproval_2502105"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Redundancy Approval",
            "type": "process",
            "event": {
              "process": "process_EmployeeRedundancyApproval_2506590"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Charge Hand Over Approval",
            "type": "process",
            "event": {
              "process": "process_SuccessorReview_2501831"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Leave Approval",
            "type": "process",
            "event": {
              "process": "process_LeaveRequestApproval_2501066"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Onduty Approval",
            "type": "process",
            "event": {
              "process": "process_OnDutyApproval_2505801"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Loan Approval",
            "type": "process",
            "event": {
              "process": "process_ApproveLoans_2512085"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Loan Hold Approval",
            "type": "process",
            "event": {
              "process": "process_HoldApproval_2514814"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Advance Approval",
            "type": "process",
            "event": {
              "process": "process_AdvanceApproval_2505917"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Claim Approval",
            "type": "process",
            "event": {
              "process": "process_ClaimApproval_2511714"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Payroll Approval",
            "type": "process",
            "event": {
              "process": "process_PayrollApprovals_2535782"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Payroll",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Salary Configuration",
            "type": "process",
            "event": {
              "process": "process_SalaryConfiguration_2509686"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Employee Salary Mapping",
            "type": "process",
            "event": {
              "process": "process_SalConfigTOEmployeeMapper_2510311"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "IRS configuration",
            "type": "process",
            "event": {
              "process": "process_TaxSlabs_2510836"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Salary Generation",
            "type": "process",
            "event": {
              "process": "process_PayCalendar_2510701"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Pay Cycle Setup",
            "type": "process",
            "event": {
              "process": "process_PayCycleSetup_2510708"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Salary Increment",
            "type": "process",
            "event": {
              "process": "process_IncrementForContractors_2526480"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Financial",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Loan Issue",
            "type": "process",
            "event": {
              "process": "process_LoansIssue_2512587"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Advance Issue",
            "type": "process",
            "event": {
              "process": "process_AdvanceIssue_2506414"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Claim Settlement",
            "type": "process",
            "event": {
              "process": "process_ClaimSettlement_2511821"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Account Payroll",
            "type": "process",
            "event": {
              "process": "process_PayrollAccounting_2520575"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Provider Payment",
            "type": "process",
            "event": {
              "process": "process_ServiceproviderPayments_2538945"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Time and Attendance",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Attendance Card",
            "type": "process",
            "event": {
              "process": "process_AttendanceCard_2507080"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Holiday Calendar",
        "type": "process",
        "event": {
          "process": "process_Holidays_2522794"
        },
        "favourite": false,
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Sales",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Masters",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Customer",
            "type": "process",
            "event": {
              "process": "process_Customer_1558382"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Customer Group",
            "type": "process",
            "event": {
              "process": "process_CustomerGroup_886296"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Customer Type",
            "type": "process",
            "event": {
              "process": "process_CustomerType_886295"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Customer Category",
            "type": "process",
            "event": {
              "process": "process_CustomerCategory_1553924"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Loading Type",
            "type": "process",
            "event": {
              "process": "process_LoadingType_2366244"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Contractor",
            "type": "process",
            "event": {
              "process": "process_Contractors_2357628"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material",
            "type": "process",
            "event": {
              "process": "process_MaterialType_2366554"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Dumper Weight",
            "type": "process",
            "event": {
              "process": "process_Dumperweight_2440022"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sale Item",
            "type": "process",
            "event": {
              "process": "process_SaleItem_2453093"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Customer Credit Limit",
            "type": "process",
            "event": {
              "process": "process_CustomerCreditLimit_2030684"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Customer Price List",
            "type": "process",
            "event": {
              "process": "process_CustomerPriceList_2432754"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales Promotion Setup",
            "type": "process",
            "event": {
              "process": "process_SalesPromotions_1572802"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Destination Transport Discount",
            "type": "process",
            "event": {
              "process": "process_DestinationTransportDiscount_2557581"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Requests",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Loading Permit",
            "type": "process",
            "event": {
              "process": "process_LoadingPermitNew_2364642"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Proforma Invoice",
            "type": "process",
            "event": {
              "process": "process_ProformaInvoice_2364614"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Proforma Invoice Approval",
            "type": "process",
            "event": {
              "process": "process_ProformaInvoiceApproval_2425365"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Packing List",
            "type": "process",
            "event": {
              "process": "process_PackingList_2364750"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Weighment",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Raw Material - IN",
            "type": "process",
            "event": {
              "process": "process_WeighmentIN_2357634_Weighment_9"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Raw Material - OUT",
            "type": "process",
            "event": {
              "process": "process_EmptyWeighment_2357639"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales - Weighment IN",
            "type": "process",
            "event": {
              "process": "process_SalesWeighmentIn_2362887"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales - Packing Plant",
            "type": "process",
            "event": {
              "process": "process_PackingPlant_2558283"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales - Weighment OUT",
            "type": "process",
            "event": {
              "process": "process_SalesWeighmentOut_2362928"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Way Bill Generation",
            "type": "process",
            "event": {
              "process": "process_GenerateWayBill_2363688"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Invoice",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Sales Invoice - Local",
            "type": "process",
            "event": {
              "process": "process_SalesInvoices_2362946"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales Invoice - Export",
            "type": "process",
            "event": {
              "process": "process_exportInvoice_2364754"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Raw Material Invoice",
            "type": "process",
            "event": {
              "process": "process_RawMaterialInvoice_2558364"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Raw Material Invoice Approval",
            "type": "process",
            "event": {
              "process": "process_RawMaterialInvoiceApproval_2558366"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Sales Correction",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Raw Material",
            "type": "process",
            "event": {
              "process": "process_ModifyWeighment_2459145"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Gate Entry",
            "type": "process",
            "event": {
              "process": "process_GateEntry_2558378"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Loading Permit",
            "type": "process",
            "event": {
              "process": "process_LoadingPermitCorrections_2488966"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales Invoice - Local [Correction]",
            "type": "process",
            "event": {
              "process": "process_Invoicependingcorrection_2558342"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales Invoice - Export [Correction]",
            "type": "process",
            "event": {
              "process": "process_ExportInvoiceCorrection_2558343"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Gate Entries Allow",
            "type": "process",
            "event": {
              "process": "process_GateEntriesAllow_2558412"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Sales Print Documents",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Raw Material Print",
            "type": "process",
            "event": {
              "process": "process_gateoutreprint_2446308"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Loading Permit Print",
            "type": "process",
            "event": {
              "process": "process_LoadingPermit_2558406"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Local Sales Invoice Print",
            "type": "process",
            "event": {
              "process": "process_PrintDocuments_2366357"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Export Sales Invoice Print",
            "type": "process",
            "event": {
              "process": "process_ExpPrintDocuments_2368405"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Sales History",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Loading Permit History",
            "type": "process",
            "event": {
              "process": "process_LoadingPermitHistory_2558308"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Proforma Invoice History",
            "type": "process",
            "event": {
              "process": "process_ProformaInvoiceHistory_2558376"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Raw Material History",
            "type": "process",
            "event": {
              "process": "process_RawMaterialHistory_2558305"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales - Weighment In History",
            "type": "process",
            "event": {
              "process": "process_WeighmentInHistory_2558306"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales - Packing Plant History",
            "type": "process",
            "event": {
              "process": "process_Packing_2558312"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales  - Weighment Out History",
            "type": "process",
            "event": {
              "process": "process_WeighmentOutHistory_2558307"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Way Bill Local History",
            "type": "process",
            "event": {
              "process": "process_WayBill_2558309"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales Invoice - Local History",
            "type": "process",
            "event": {
              "process": "process_SalesInvoiceLocal_2558310"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Way Bill Export History",
            "type": "process",
            "event": {
              "process": "process_ExportWayBillHistory_2558377"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Sales Invoice - Export History",
            "type": "process",
            "event": {
              "process": "process_SalesInvoiceExport_2558311"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Procurement",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Masters",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Purchase Type",
            "type": "process",
            "event": {
              "process": "process_PurchaseType_886329"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Purchase Category",
            "type": "process",
            "event": {
              "process": "process_PurchaseCategory_886327"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Vendor",
            "type": "process",
            "event": {
              "process": "process_Vendor_1306625"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Vendor Item Mapping",
            "type": "process",
            "event": {
              "process": "process_VendorItemMapping_896818"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Vendor Price List",
            "type": "process",
            "event": {
              "process": "process_VendorPricelist_2051601"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Purchase",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Indent",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Purchase Indent",
                "type": "process",
                "event": {
                  "process": "process_PurchaseIndent_886355"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Purchase Indent Approval",
                "type": "process",
                "event": {
                  "process": "process_IndentConversion_886376"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Purchase Indent Pending",
                "type": "process",
                "event": {
                  "process": "process_IndentApprovalsList_2302863"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "RFQ",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Local",
                "type": "group",
                "favourite": false,
                "subMenus": [
                  {
                    "name": "Request for Quote - Creation",
                    "type": "process",
                    "event": {
                      "process": "process_LRFQNEW_2302883"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Request for Quote - Approval",
                    "type": "process",
                    "event": {
                      "process": "process_LocalRFQApproval_886361"
                    },
                    "favourite": false,
                    "build": true
                  }
                ],
                "build": true
              },
              {
                "name": "Foreign",
                "type": "group",
                "favourite": false,
                "subMenus": [
                  {
                    "name": "Request for Quote - Creation",
                    "type": "process",
                    "event": {
                      "process": "process_FRFQNEW_2302954"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Request for Quote - Approval",
                    "type": "process",
                    "event": {
                      "process": "process_ForeignRFQApproval_886372"
                    },
                    "favourite": false,
                    "build": true
                  }
                ],
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Quote",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Local",
                "type": "group",
                "favourite": false,
                "subMenus": [
                  {
                    "name": "Quote Receipt",
                    "type": "process",
                    "event": {
                      "process": "process_LocalQuote_1695519"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Quote Review",
                    "type": "process",
                    "event": {
                      "process": "process_QuoteReview_1703464"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Quote Finalization",
                    "type": "process",
                    "event": {
                      "process": "process_QuoteFinalization_1704426"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Approved Quote",
                    "type": "process",
                    "event": {
                      "process": "process_ApprovedQuotes_2303864"
                    },
                    "favourite": false,
                    "build": true
                  }
                ],
                "build": true
              },
              {
                "name": "Foreign",
                "type": "group",
                "favourite": false,
                "subMenus": [
                  {
                    "name": "Quote Receipt",
                    "type": "process",
                    "event": {
                      "process": "process_ForeignQuote_2078412"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Quote Review",
                    "type": "process",
                    "event": {
                      "process": "process_QuoteReview_2078889"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Quote Finalization",
                    "type": "process",
                    "event": {
                      "process": "process_QuoteFinalization_2081761"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Approved Quote",
                    "type": "process",
                    "event": {
                      "process": "process_QuoteApprovals_2080325"
                    },
                    "favourite": false,
                    "build": true
                  }
                ],
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Order",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Local",
                "type": "group",
                "favourite": false,
                "subMenus": [
                  {
                    "name": "Purchase Order - Creation",
                    "type": "process",
                    "event": {
                      "process": "process_lpoNew_2303934"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Purchase Order - Approval",
                    "type": "process",
                    "event": {
                      "process": "process_PurchaseOrderApprovals_1729438"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "LPO Amend",
                    "type": "process",
                    "event": {
                      "process": "process_AmendPO_2488998"
                    },
                    "favourite": false,
                    "build": true
                  }
                ],
                "build": true
              },
              {
                "name": "Foreign",
                "type": "group",
                "favourite": false,
                "subMenus": [
                  {
                    "name": "Purchase Order - Creation",
                    "type": "process",
                    "event": {
                      "process": "process_FPONew_2310077"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "Purchase Order - Approval",
                    "type": "process",
                    "event": {
                      "process": "process_FPOApprovals_2107526"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "FPO Amend",
                    "type": "process",
                    "event": {
                      "process": "process_FPOAmend_2558326"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "FPO Delegation",
                    "type": "process",
                    "event": {
                      "process": "process_FPOfollowup_2520624"
                    },
                    "favourite": false,
                    "build": true
                  },
                  {
                    "name": "FPO Tracking",
                    "type": "process",
                    "event": {
                      "process": "process_FPOTracking_2526950"
                    },
                    "favourite": false,
                    "build": true
                  }
                ],
                "build": true
              }
            ],
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Service",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Service Request",
            "type": "process",
            "event": {
              "process": "process_ServiceRequest_6538866"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Request Approval",
            "type": "process",
            "event": {
              "process": "process_ServiceRequestApproval_2558372"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Request Pending",
            "type": "process",
            "event": {
              "process": "process_PendingRequest_6538878"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service RFQ",
            "type": "process",
            "event": {
              "process": "process_ServiceRFQ_6538895"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service RFQ Approval",
            "type": "process",
            "event": {
              "process": "process_ServiceRFQApproval_6538926"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Quote",
            "type": "process",
            "event": {
              "process": "process_ServiceQuote_6538916"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Quote Approval",
            "type": "process",
            "event": {
              "process": "process_ServiceQuoteApproval_6538941"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Order",
            "type": "process",
            "event": {
              "process": "process_ServiceOrder_6538956"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Order Approval",
            "type": "process",
            "event": {
              "process": "process_ServiceSOApproval_6539007"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Procurement History",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Purchase History",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Purchase Indent History",
                "type": "process",
                "event": {
                  "process": "process_PRInformation_2317829"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "RFQ - Local History",
                "type": "process",
                "event": {
                  "process": "process_LRFQNEW_2318901"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "RFQ - Foreign History",
                "type": "process",
                "event": {
                  "process": "process_FRFQNEW_2318964"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Purchase Quote - Local History",
                "type": "process",
                "event": {
                  "process": "process_QuoteReview_2318944"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Purchase Quote - Foreign History",
                "type": "process",
                "event": {
                  "process": "process_FQuoteReview_2318997"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Purchase Order - Local History",
                "type": "process",
                "event": {
                  "process": "process_PurchaseOrderApprovals_2318956"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Purchase Order - Foreign History",
                "type": "process",
                "event": {
                  "process": "process_FPONew_2318985"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Service History",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Service Request History",
                "type": "process",
                "event": {
                  "process": "process_ServiceRequestHistory_2558318"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Service RFQ History",
                "type": "process",
                "event": {
                  "process": "process_ServiceRFQ_2558319"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Service Quote History",
                "type": "process",
                "event": {
                  "process": "process_ServiceQuote_2558320"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Service Order History",
                "type": "process",
                "event": {
                  "process": "process_ServiceOrderHistory_2558321"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          }
        ],
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Inventory",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Masters",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Item Group",
            "type": "process",
            "event": {
              "process": "process_ItemGroup_886282"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Item Sub Group",
            "type": "process",
            "event": {
              "process": "process_ItemSubGroup_886284"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Item Sub SubGroup",
            "type": "process",
            "event": {
              "process": "process_ItemSubSubGroup_886283"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Item",
            "type": "process",
            "event": {
              "process": "process_ItemMaster_1478030"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Item Category",
            "type": "process",
            "event": {
              "process": "process_ItemCategories_2388184"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Item Re-Order Level",
            "type": "process",
            "event": {
              "process": "process_Inventorydata_2346150"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "UOM Conversion",
            "type": "process",
            "event": {
              "process": "process_uomConversion_2040141"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Machine",
            "type": "process",
            "event": {
              "process": "process_AssetsCreate_1235432"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Item Inventory Map",
            "type": "process",
            "event": {
              "process": "process_ItemInventoryMap_2558290"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Warehouse",
            "type": "process",
            "event": {
              "process": "process_Warehouse_886324"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Location",
            "type": "process",
            "event": {
              "process": "process_Location_886314"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Area",
            "type": "process",
            "event": {
              "process": "process_BinType_1467463"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Rack",
            "type": "process",
            "event": {
              "process": "process_Bin_1467464"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Requests",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Fuel Request",
            "type": "process",
            "event": {
              "process": "process_FuelRequest_2395845"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Fuel Request Approval",
            "type": "process",
            "event": {
              "process": "process_FuelRequestApproval_2395996"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Request Note",
            "type": "process",
            "event": {
              "process": "process_StockRequest_1527137"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Request Approval",
            "type": "process",
            "event": {
              "process": "process_StockRequestApproval_1578693"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Issues",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Fuel Issue",
            "type": "process",
            "event": {
              "process": "process_FuelIssue_2396139"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Fuel Issue Approval",
            "type": "process",
            "event": {
              "process": "process_FuelIssueApproval_2396222"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Issue",
            "type": "process",
            "event": {
              "process": "process_StockIssue_1580841"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Issue Approval",
            "type": "process",
            "event": {
              "process": "process_stockissueApproval_2370048"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Gate Pass",
            "type": "process",
            "event": {
              "process": "process_GatePass_2311105"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Gate Pass Approval",
            "type": "process",
            "event": {
              "process": "process_GatePassApproval_2311123"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Gate Pass - Pending",
            "type": "process",
            "event": {
              "process": "process_PendingReturnGatePass_2374019"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Receipts",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Material Inward",
            "type": "process",
            "event": {
              "process": "process_MaterialInward_2558356"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Inward Approval",
            "type": "process",
            "event": {
              "process": "process_MaterialInwardApproval_2558359"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Goods Receipt Note",
            "type": "process",
            "event": {
              "process": "process_GRN_1618694"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "GRN Approval",
            "type": "process",
            "event": {
              "process": "process_grnApproval_1784755"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Stock",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Stock Opening Balance",
            "type": "process",
            "event": {
              "process": "process_StockOpenings_1406142"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Stock Opening Approval",
            "type": "process",
            "event": {
              "process": "process_StockOpeningApproval_1431678"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Stock Reconcile",
            "type": "process",
            "event": {
              "process": "process_StockOBupdate_2459669"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Return Management",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Purchase Return",
            "type": "process",
            "event": {
              "process": "process_PurchaseReturn_2055886"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Purchase Return Approval",
            "type": "process",
            "event": {
              "process": "process_PurchaseReturnApproval_2107529"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Stores Return",
            "type": "process",
            "event": {
              "process": "process_StoresReturn_2132097"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Stores Return Approval",
            "type": "process",
            "event": {
              "process": "process_StoresReturnApproval_2308471"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Inventory History",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Fuel Request History",
            "type": "process",
            "event": {
              "process": "process_FuelRequestHistory_2558401"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Fuel Issue History",
            "type": "process",
            "event": {
              "process": "process_FuelIssueHistory_2558402"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Gate Pass History",
            "type": "process",
            "event": {
              "process": "process_GatePassHistory_2558403"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Request History",
            "type": "process",
            "event": {
              "process": "process_IndentHistory_2351512"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Issue History",
            "type": "process",
            "event": {
              "process": "process_IssueHistory_2351543"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Material Inward History",
            "type": "process",
            "event": {
              "process": "process_MaterialInwardHistory_2558404"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Goods Receipt Note History",
            "type": "process",
            "event": {
              "process": "process_GRN_2319024"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Purchase Return History",
            "type": "process",
            "event": {
              "process": "process_PurchaseReturn_2558405"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Stores Return History",
            "type": "process",
            "event": {
              "process": "process_StoresReturn_2351735"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Finance",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Masters",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "COA -  Account Group",
            "type": "process",
            "event": {
              "process": "process_COA_2378266"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "COA - Account Master",
            "type": "process",
            "event": {
              "process": "process_accmasters_2379960"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Forex Master",
            "type": "process",
            "event": {
              "process": "process_ForexMaster_2319842"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Forex Master Approval",
            "type": "process",
            "event": {
              "process": "process_ForexMastersApproval_2319883"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Bank",
            "type": "process",
            "event": {
              "process": "process_Bank_2319837"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Bank Account",
            "type": "process",
            "event": {
              "process": "process_BankAccount_2319838"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Cash Account",
            "type": "process",
            "event": {
              "process": "process_CashAccount_2319839"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Cheque Management",
            "type": "process",
            "event": {
              "process": "process_ChequeManagement_2319840"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Cheque Register",
            "type": "process",
            "event": {
              "process": "process_ChequeRegister_2319920"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Control Account Mapping",
            "type": "process",
            "event": {
              "process": "process_ControlAccountMapping_2326485"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Voucher Configuration",
            "type": "process",
            "event": {
              "process": "process_VoucherConfigurations_2417706"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Interest Terms",
            "type": "process",
            "event": {
              "process": "process_InterestTerms_2506905"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Segment Group",
            "type": "process",
            "event": {
              "process": "process_SegmentGroup_2510919"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Segment",
            "type": "process",
            "event": {
              "process": "process_Segment_2510924"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "IT Assessment Calendar",
            "type": "process",
            "event": {
              "process": "process_ITStatus_2526799"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "General Ledgers",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Journals",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Opening Balance",
                "type": "process",
                "event": {
                  "process": "process_OpeningBalance_2331401"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Opening Balance Approval",
                "type": "process",
                "event": {
                  "process": "process_OpeningBalanceApprovals_2331418"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Journal Voucher",
                "type": "process",
                "event": {
                  "process": "process_JournalVoucher_2317526"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Journal Voucher Approval",
                "type": "process",
                "event": {
                  "process": "process_JournalVoucherApprovals_2317527"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Reverse Journal Voucher",
                "type": "process",
                "event": {
                  "process": "process_ReverseJournalVoucher_2332871"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Reverse Journal Voucher Approval",
                "type": "process",
                "event": {
                  "process": "process_ReverseJournalVoucherApprovals_2333383"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Bank Reconciliation",
                "type": "process",
                "event": {
                  "process": "process_bankrecprocess_2489042"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Vendor Customer OB",
                "type": "process",
                "event": {
                  "process": "process_VendorOpeningBalances_2540004"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Ledger Reversal",
                "type": "process",
                "event": {
                  "process": "process_LedgerReversal_2558293"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Account Payables",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Bank Payment",
                "type": "process",
                "event": {
                  "process": "process_BankPayments_2317431"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Bank Payment Approval",
                "type": "process",
                "event": {
                  "process": "process_BankPaymentsApprovals_2317432"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Cash Payment",
                "type": "process",
                "event": {
                  "process": "process_CashPayment_2317334"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Cash Payment Approval",
                "type": "process",
                "event": {
                  "process": "process_CashPaymentApprovals_2317374"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Contra Entries",
                "type": "process",
                "event": {
                  "process": "process_ContraEntry_2419927"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Bank Counter Voucher",
                "type": "process",
                "event": {
                  "process": "process_bankcounternew_2473466"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Bank Counter Approval",
                "type": "process",
                "event": {
                  "process": "process_bankcountermultiapprovals_2473631"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Accounts Receivables",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "Bank Receipt",
                "type": "process",
                "event": {
                  "process": "process_BankReceipts_2317479"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Bank Receipt Approval",
                "type": "process",
                "event": {
                  "process": "process_BankReceiptsApprovals_2317480"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Cash Receipt",
                "type": "process",
                "event": {
                  "process": "process_CashReceiptsNew_2317225"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Cash Receipt Approval",
                "type": "process",
                "event": {
                  "process": "process_CashReceiptApprovals_2317238"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Interest Calculation",
                "type": "process",
                "event": {
                  "process": "process_InterestCalculation_2506918"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Interest Calculation Approval",
                "type": "process",
                "event": {
                  "process": "process_InterestCalculationApproval_2506986"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Adjustments",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "AP Adjustment Auto",
            "type": "process",
            "event": {
              "process": "process_apadjustmentsAuto_2383239"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "AR Adjustment Auto",
            "type": "process",
            "event": {
              "process": "process_aradjustAuto_2387286"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "AR Adjustment View",
            "type": "process",
            "event": {
              "process": "process_AdjustmentsView_2438958"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "AP Adjustment View",
            "type": "process",
            "event": {
              "process": "process_AdustmentsAPView_2439024"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Integration Configurations",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Integration Master",
            "type": "process",
            "event": {
              "process": "process_IntegrationMaster_2336352"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Taxation",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Tax Formula",
            "type": "process",
            "event": {
              "process": "process_TaxFormula_1829856"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Tax Component Profile",
            "type": "process",
            "event": {
              "process": "process_TaxComponentProfile_1835305"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Purchase Invoices",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Pending GRN",
            "type": "process",
            "event": {
              "process": "process_GeneratePurchaseInvoice_2435710"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Purchase Invoice",
            "type": "process",
            "event": {
              "process": "process_LPOInvoices_2415866"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Purchase Invoice Approval",
            "type": "process",
            "event": {
              "process": "process_PurchaseInvoiceApproval_2558398"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Invoice",
            "type": "process",
            "event": {
              "process": "process_PurchaseServiceInvoice_2477829"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Invoice Approval",
            "type": "process",
            "event": {
              "process": "process_PuchaseServiceInvoiceApproval_2477868"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Budgeting",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Budget Profile",
            "type": "process",
            "event": {
              "process": "process_BudgetProfile_2510722"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Structure",
            "type": "process",
            "event": {
              "process": "process_Structure_2510750"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Structure Group",
            "type": "process",
            "event": {
              "process": "process_StructureGroup_2510760"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Budget Creation",
            "type": "process",
            "event": {
              "process": "process_BudgetCreation_2510814"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Budget Creation Approval",
            "type": "process",
            "event": {
              "process": "process_BudgetCreationApproval_2522122"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Finance History",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Journal Voucher History",
            "type": "process",
            "event": {
              "process": "process_JournalVoucherHistory_2558381"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Reverse JV History",
            "type": "process",
            "event": {
              "process": "process_ReverseJVHistory_2558382"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Bank Reconciliation History",
            "type": "process",
            "event": {
              "process": "process_BankReconciliationHistory_2558383"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Ledger Reversal History",
            "type": "process",
            "event": {
              "process": "process_LedgerReversalHistory_2558384"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Bank Payment History",
            "type": "process",
            "event": {
              "process": "process_BankPayment_2558385"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Cash Payment History",
            "type": "process",
            "event": {
              "process": "process_CashPaymentHistory_2558386"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Contra Entries History",
            "type": "process",
            "event": {
              "process": "process_ContraEntriesHistory_2558387"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Bank Counter History",
            "type": "process",
            "event": {
              "process": "process_BankCounterHistory_2558388"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Bank Receipt History",
            "type": "process",
            "event": {
              "process": "process_BankReceiptHistory_2558389"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Cash Receipt History",
            "type": "process",
            "event": {
              "process": "process_CashReceiptHistory_2558390"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Purchase Invoice History",
            "type": "process",
            "event": {
              "process": "process_PurchaseInvoiceHistory_2558391"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "Service Invoice History",
            "type": "process",
            "event": {
              "process": "process_ServiceInvoiceHistory_2558392"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "General Ledger",
            "type": "process",
            "event": {
              "process": "process_GeneralLedgerReport_2328153"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Daily Production",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Configuration",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "Month To Date",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "RM Config",
                "type": "process",
                "event": {
                  "process": "process_ConsolidatedRMProduction_2485412"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "RM/Contractor",
                "type": "process",
                "event": {
                  "process": "process_ConsolidatedRMPerContractor_2485366"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "RM/Screen",
                "type": "process",
                "event": {
                  "process": "process_ConsolidatedScreenRMperMonth_2485395"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Power Config",
                "type": "process",
                "event": {
                  "process": "process_ConsolidatedPowerPerMonth_2485387"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Sales Config",
                "type": "process",
                "event": {
                  "process": "process_MonthlyConsolidatedUplifitin_2491644"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Power Locations",
                "type": "process",
                "event": {
                  "process": "process_PowerConsumptionLocTrans_2483151"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Dpr Materials",
                "type": "process",
                "event": {
                  "process": "process_DprMaterials_2558285"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Paper Closing",
                "type": "process",
                "event": {
                  "process": "process_DPRClosing_2558303"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          },
          {
            "name": "Year To Date",
            "type": "group",
            "favourite": false,
            "subMenus": [
              {
                "name": "RM Config",
                "type": "process",
                "event": {
                  "process": "process_YearlyConsolidatedRMProduction_2485514"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "RM/Contractor",
                "type": "process",
                "event": {
                  "process": "process_YearlyRMPerContractor_2485517"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "RM/Screen",
                "type": "process",
                "event": {
                  "process": "process_YearlyRMPerScreen_2485520"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Power Config",
                "type": "process",
                "event": {
                  "process": "process_YearlyPowerConsumption_2491701"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Sales Config",
                "type": "process",
                "event": {
                  "process": "process_YearlyConsolidatedUplifting_2491645"
                },
                "favourite": false,
                "build": true
              },
              {
                "name": "Mines Stock Holder",
                "type": "process",
                "event": {
                  "process": "process_MinesStockHolder_2543229"
                },
                "favourite": false,
                "build": true
              }
            ],
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Daily Power Consumption",
        "type": "process",
        "event": {
          "process": "process_DailyPowerConsumption_2483165"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Daily Performance Status",
        "type": "process",
        "event": {
          "process": "process_DailyPerformanceProcess_2484203"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Daily Production Entry",
        "type": "process",
        "event": {
          "process": "process_dailyproduction_2425295"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Daily Quality Analysis",
        "type": "process",
        "event": {
          "process": "process_LabAnalysis_2537312"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "DPR",
        "type": "process",
        "event": {
          "process": "process_DPR_2558287"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "DPR MOnthly",
        "type": "process",
        "event": {
          "process": "process_DPRMOnthly_2558288"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "DPR Yearly",
        "type": "process",
        "event": {
          "process": "process_DPRYearly_2558289"
        },
        "favourite": false,
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Support",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Raise A Ticket",
        "type": "process",
        "event": {
          "process": "process_RaiseaTicket_2442237"
        },
        "favourite": false,
        "build": true
      }
    ],
    "build": true
  },
  {
    "name": "Internal",
    "type": "group",
    "favourite": false,
    "subMenus": [
      {
        "name": "Internal",
        "type": "group",
        "favourite": false,
        "subMenus": [
          {
            "name": "openingstockDelete",
            "type": "process",
            "event": {
              "process": "process_openingstockDelete_2371996"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "stockrequestdelete",
            "type": "process",
            "event": {
              "process": "process_stockrequestdelete_2371998"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "stockissuedelete",
            "type": "process",
            "event": {
              "process": "process_stockissuedelete_2372000"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "ViewDelete-StockLedger2",
            "type": "process",
            "event": {
              "process": "process_ViewDelete-StockLedger2_1558511"
            },
            "favourite": false,
            "build": true
          },
          {
            "name": "ViewDelete-StockMaster",
            "type": "process",
            "event": {
              "process": "process_ViewDelete-StockMaster_1273972"
            },
            "favourite": false,
            "build": true
          }
        ],
        "build": true
      },
      {
        "name": "Imported Attendance",
        "type": "process",
        "event": {
          "process": "process_ImportAttendance_2523312"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Import Scheduler",
        "type": "process",
        "event": {
          "process": "process_ImportScheduler_2523383"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Medial Attendance",
        "type": "process",
        "event": {
          "process": "process_MedialAttendanceView_2527588"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Final Attendance",
        "type": "process",
        "event": {
          "process": "process_finalAttendanceView_2527592"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Track Scheduler",
        "type": "process",
        "event": {
          "process": "process_trackScheduler_2527586"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "raw Attendance Remove",
        "type": "process",
        "event": {
          "process": "process_rawAttendanceRemove_2550443"
        },
        "favourite": false,
        "build": true
      },
      {
        "name": "Announcements",
        "type": "process",
        "event": {
          "process": "process_Announcements_2558330"
        },
        "favourite": false,
        "build": true
      }
    ],
    "build": true
  }
]